﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

class Program
{
    private static readonly string slackToken = "xoxb-7940383671157-7943401367490-BrtnGShi2ZDt7asLFPbjl8u8";  // Replace with your Slack Bot or User Token
    private static readonly string fileName = @"C:\artifact.exe";  // Replace with your file name
    private static readonly int fileLength = (int)new FileInfo(fileName).Length;  // Replace with your file size in bytes
    private static readonly string channelId = "C07TALNBU2K";  // Replace with your file name
    static async Task Main(string[] args)
    {
        try
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            // Get both uploadUrl and uploadId
            var (uploadUrl, uploadId) = await GetUploadUrlAsync();
            Console.WriteLine("Upload URL: " + uploadUrl);
            Console.WriteLine("Upload ID: " + uploadId);

            // Create the file metadata with the required 'id' field (uploadId)
            var files = new List<Dictionary<string, string>> {
    new Dictionary<string, string> {
        { "id", uploadId },
        {
            "title", "test"
        } 
    }
};

            // Call CompleteUploadExternalAsync with the file metadata
            var response = await CompleteUploadExternalAsync(files,channelId);
            Console.WriteLine("Upload completed: " + response);
        }
        catch (Exception ex)
        {
            Console.WriteLine("An error occurred: " + ex.Message);
        }
    }



    public static async Task<(string uploadUrl, string uploadId)> GetUploadUrlAsync()
    {
        using (var client = new HttpClient())
        {
            var url = "https://slack.com/api/files.getUploadURLExternal";
            var parameters = new FormUrlEncodedContent(new[] {
            new KeyValuePair<string, string>("token", slackToken),
            new KeyValuePair<string, string>("filename", fileName),
            new KeyValuePair<string, string>("length", fileLength.ToString())
        });

            var response = await client.PostAsync(url, parameters);
            response.EnsureSuccessStatusCode();
            var content = await response.Content.ReadAsByteArrayAsync();
            var contentString = System.Text.Encoding.UTF8.GetString(content);

            if (contentString.Contains("\"ok\":true"))
            {
                var uploadUrlStart = contentString.IndexOf("\"upload_url\":\"") + "\"upload_url\":\"".Length;
                var uploadUrlEnd = contentString.IndexOf("\"", uploadUrlStart);
                var uploadUrl = contentString.Substring(uploadUrlStart, uploadUrlEnd - uploadUrlStart);

                var uploadIdStart = contentString.IndexOf("\"file_id\":\"") + "\"file_id\":\"".Length;
                var uploadIdEnd = contentString.IndexOf("\"", uploadIdStart);
                var uploadId = contentString.Substring(uploadIdStart, uploadIdEnd - uploadIdStart);

                return (uploadUrl, uploadId); // Return both uploadUrl and uploadId
            }
            else
            {
                throw new Exception("Failed to get upload URL: " + contentString);
            }
        }
    }

    public static async Task<string> CompleteUploadExternalAsync(List<Dictionary<string, string>> files, string channelId = null)
    {
        using (var client = new HttpClient())
        {
            var url = "https://slack.com/api/files.completeUploadExternal";

            // Prepare the request parameters
            var parameters = new List<KeyValuePair<string, string>>
        {
            new KeyValuePair<string, string>("token", slackToken),
            // Add files parameter as JSON string
            new KeyValuePair<string, string>("files", JsonConvert.SerializeObject(files))
        };

            // Add channel_id if provided
            if (!string.IsNullOrEmpty(channelId))
            {
                parameters.Add(new KeyValuePair<string, string>("channels", channelId));  // Use 'channels' instead of 'channel_id'
            }

            var content = new FormUrlEncodedContent(parameters);

            // Make the POST request
            var response = await client.PostAsync(url, content);
            response.EnsureSuccessStatusCode();

            // Read and parse the response
            var responseContent = await response.Content.ReadAsStringAsync();

            // Check if the response is successful
            if (responseContent.Contains("\"ok\":true"))
            {
                return responseContent;
            }
            else
            {
                throw new Exception("Failed to complete upload: " + responseContent);
            }
        }
    }




}
